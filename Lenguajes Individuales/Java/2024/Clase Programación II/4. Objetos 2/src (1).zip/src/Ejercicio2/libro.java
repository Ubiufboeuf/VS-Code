package Ejercicio2;

public class libro {
    private String titulo;
    private String autorNombre;
    private String autorn;
    private String code;
    private int precio;

    public String getTitulo() {
        return titulo;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getAutorNombre() {
        return autorNombre;
    }
    
    public void setAutorNombre(String autorNombre) {
        this.autorNombre = autorNombre;
    }
    
    public String getAutorn() {
        return autorn;
    }
    
    public void setAutorn(String autorn) {
        this.autorn = autorn;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public int getPrecio() {
        return precio;
    }
    
    public void setPrecio(int precio) {
        this.precio = precio;
    }

}
