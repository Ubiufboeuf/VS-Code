class ItemDAO{
    nextPage=null;
    previousPage=null;


    
    async obtenerCategorias(){
        
        let url = "https://pokeapi.co/api/v2/item-category?limit=54";
        let consulta = await fetch(url);
        let resultado = await consulta.json();
        let categorias = resultado.results;
        this.nextPage = resultado.next;
        this.previousPage = resultado.previous;       
        categorias = await this.obtenerDataCategorias(categorias);
        return categorias;
    }

    async obtenerDataCategorias(categorias){
        let dataCateogrias = [];
        await Promise.all(categorias.map(async(categoria) => {
            let consulta = await fetch(categoria.url);
            let data =await consulta.json();
       
            let dataCategoria = {
                nombre:data.name,
                items:data.items
            }
            dataCateogrias.push(dataCategoria);
        }));
        return dataCateogrias;
    }

    async obtenerItems(categoria) {
        let itemsList = categoria.items;
        let items= [];
        await Promise.all(itemsList.map(async (itemList) => {
            let url = itemList.url;
            let consulta = await fetch(url);
            let itemData  = await consulta.json();
            let item = {
                nombre:itemData.name,
                img:itemData.sprites.default
            }
            items.push(item);

        }));
        return items;
    }

    async obtenerUrlImgItem(urlItemBerry){
        let consulta = await fetch(urlItemBerry);
        let resultado = await consulta.json();
        return resultado.sprites.default;
    }

    async obtenerNextItems(){
        let url = this.nextPage;
        if(url !=null){
            let consulta = await fetch(url);
            let resultado = await consulta.json();
            let berrys = resultado.results;
            this.nextPage = resultado.next;
            this.previousPage = resultado.previous;
            berrys = await this.obtenerDataBerrys(berrys);
            return berrys;
        }else{
            return null;
        }
        
    }
    
    async obtenerPreviousItems(){
        let url = this.previousPage;
        if(url !=null){
            let consulta = await fetch(url);
            let resultado = await consulta.json();
            let berrys = resultado.results;
            this.nextPage = resultado.next;
            this.previousPage = resultado.previous;
            berrys = await this.obtenerDataBerrys(berrys);
            return berrys;
        }else{
            return null;
        }

    }
}

export default ItemDAO;