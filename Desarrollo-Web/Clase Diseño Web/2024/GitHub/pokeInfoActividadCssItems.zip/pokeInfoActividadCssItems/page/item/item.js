import ItemController from "../../controller/itemController.js";

let itemController = new ItemController();

window.onload = async ()=>{
    let categorias =await itemController.obtenerCategorias();
    mostrarCategorias(categorias);
   
}


function mostrarCategorias(categorias){
    let listaCategoriasElement = document.querySelector("#listaCategorias");
    listaCategoriasElement.innerHTML="";
    categorias.forEach(categoria => {
        let  divCategoriaElement = document.createElement("div");
        divCategoriaElement.className="categoria";
        divCategoriaElement.innerHTML = `
            <p class="nombreCategoria">${categoria.nombre}</p>
            <p class="cantidadItemsCategoria">${categoria.items.length}</p>
        `;
        listaCategoriasElement.appendChild(divCategoriaElement);
        divCategoriaElement.onclick = async ()=>{
            let items = await itemController.obtenerItems(categoria);
            mostrarItems(items);
        }
    });

async function mostrarItems(items){
    let listaItemsElement = document.querySelector("#listaItems");
    listaItemsElement.innerHTML="";
    items.forEach((item)=>{
        listaItemsElement.innerHTML+= `
            <div class="item">
                <p class="nombre">${item.nombre}</p>
                <img src="${item.img}">
            </div>
        `;
    });
}


}