import ItemDAO from "../model/dao/ItemDAO.js";

class ItemController{

    itemDAO;

    constructor(){
        this.itemDAO = new ItemDAO();
    }

    async obtenerCategorias(){
        return await this.itemDAO.obtenerCategorias();
    }

    async obtenerItems(categoria){
        return await this.itemDAO.obtenerItems(categoria);
    }
}

export default ItemController;