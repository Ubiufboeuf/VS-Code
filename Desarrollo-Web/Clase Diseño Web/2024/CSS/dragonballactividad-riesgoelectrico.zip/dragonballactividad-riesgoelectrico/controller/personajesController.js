import PersonajesDAO from "../model/personajesDAO.js";

export default class PersonajesController{

    personajeDAO;

    constructor(){
        this.personajeDAO = new PersonajesDAO();
    }
    async  obtenerPersonajes(){
        return await this.personajeDAO.obtenerPersonajes();
    }

    async obtenerPaginaSiguiente(){
        return await this.personajeDAO.obtenerPaginaSiguiente();
    }

    async obtenerPaginaAnterior(){
        return await this.personajeDAO.obtenerPaginaAnterior();
    }
}