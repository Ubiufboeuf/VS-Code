export default class PersonajesDAO{
    paginaActual;
    limite;
    paginasTotales;

    constructor(){
        this.limite=5;
        this.paginaActual=1;
    }
    


   async  obtenerPersonajes(){
        let url = `https://dragonball-api.com/api/characters?page=1&limit=${this.limite}`;
        let consulta = await fetch(url);
        let datos = await consulta.json();
        let personajes = datos.items;
        this.paginaAnterior=  datos.links.previous;
        this.paginaSiguiente = datos.links.next;
        this.paginasTotales = datos.meta.totalPages;
        return personajes;
    }

    async obtenerPaginaSiguiente(){
        let url ="";
        if(this.paginaActual < this.paginasTotales){
            this.paginaActual++;       
        }
        url = `https://dragonball-api.com/api/characters?page=${this.paginaActual}&limit=${this.limite}`;
        let consulta = await fetch(url);
        let datos = await consulta.json();
        let personajes = datos.items;
        this.paginaAnterior=  datos.links.previous;
        this.paginaSiguiente = datos.links.next;
        return personajes;
    }

    async obtenerPaginaAnterior(){
        let url ="";
        if(this.paginaActual > 1){
            this.paginaActual--;
            console.log(this.paginaActual);
        }
        url = `https://dragonball-api.com/api/characters?page=${this.paginaActual}&limit=${this.limite}`;

        let consulta = await fetch(url);
        let datos = await consulta.json();
        let personajes = datos.items;
        this.paginaAnterior=  datos.links.previous;
        this.paginaSiguiente = datos.links.next;
        return personajes;

    }
}