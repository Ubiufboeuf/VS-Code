import PersonajesController from "../../controller/personajesController.js";

let personajesController = new PersonajesController();

window.onload = async ()=>{
    let personajes =await  personajesController.obtenerPersonajes();
    mostrarPersonajes(personajes);
    agregarEventos();
}


async function obtenerPersonajes(){
    return await new PersonajesDAO().obtenerPersonajes();
}

async function obtenerPaginaSiguiente(){
    return await new PersonajesDAO().obtenerPaginaSiguiente();
}

async function obtenerPaginaAnterior(){
    return await new PersonajesDAO().obtenerPaginaAnterior();
}


function mostrarPersonajes(personajes){
 let listaPersonajesElement = document.querySelector("#listaPersonajes");
 listaPersonajesElement.innerHTML="";
 personajes.forEach(personaje => {
    let personajeElement = document.createElement("div");
    personajeElement.className ="personaje";
    personajeElement.innerHTML +=`
          <img class="imagen" src="${personaje.image}">
            <p class="nombre">${personaje.name}</p>
    `;
    personajeElement.onclick = ()=>{mostrarPersonaje(personaje)};
    listaPersonajesElement.appendChild(personajeElement);

 });
}

function agregarEventos(){
    let paginaAnteriorElement = document.querySelector("#paginaAnterior");
    let paginaSiguienteElement = document.querySelector("#paginaSiguiente");
    paginaAnteriorElement.onclick =async()=>{
        let personaje = await personajesController.obtenerPaginaAnterior();
        console.log(personaje);
        mostrarPersonajes(personaje);
    }

    paginaSiguienteElement.onclick =async()=>{
        let personaje = await personajesController.obtenerPaginaSiguiente();
        mostrarPersonajes(personaje);
    }
}

function mostrarPersonaje(personaje){
 let panelPersonajeElement= document.querySelector("#panelPersonaje");
 panelPersonajeElement.innerHTML=`
    <img class="imagen" src="${personaje.image}">
    <p class="nombre">Nombre: ${personaje.name}</p>
    <p class="ki">KI: ${personaje.ki}</p>
    <p class="kiMaximo">Ki maximo: ${personaje.maxKi}</p>
    <p class="race">Race: ${personaje.race}</p>
    <p class="descripcion"> ${personaje.description}</p>
 `;
}


/*listaPersonajesElement.innerHTML +=`
<div class="personaje">
 <img class="imagen" src="${personaje.image}">
   <p class="nombre">Nombre: ${personaje.name}</p>
   <p class="ki">KI: ${personaje.ki}</p>
   <p class="kiMaximo">Ki maximo: ${personaje.maxKi}</p>
   <p class="race">Race: ${personaje.race}</p>
</div>
`;

*/